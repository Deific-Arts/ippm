  /* ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
   * 
   * ----------------------------
   * Section Contents
   * ----------------------------
   * A: Global Variables
   * B: Functions Library
   * C: Execute Functions & Scripts   
   *
   *
   ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: */


jQuery(document).ready(function($) {

  if (window.matchMedia("(min-width: 640px)").matches) {
    $('html').removeClass('theme-auset').addClass('theme-ausar');
  }

if ( $('html').hasClass('theme-ausar') ) { // desktop only



  /* ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
   * 
   * ----------------------------
   * A: Global Variables
   * ----------------------------
   *
   ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: */

  var activeSlide = 'none';
  var lastScrollTop = 0;
  var isScrollUp = false;



  /* ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
   * 
   * ----------------------------
   * B: Functions Library
   * ----------------------------
   *
   * ------------------------------------------------------------
   * 
   * Table of Contents
   * -----------------
   *
   * 01.00 Reusable Functions
   * ------------------------
   * 01.01 getElementPos
   * 01.02 scrollToLink
   * 01.03 scrollToElem
   * 01.04 backToTop
   *
   * 02.00 General Functions
   * ----------------------- 
   * 02.01 scrollTriggers
   * 02.02 regenerateMarkup
   *
   * 03.00 Animations
   * ----------------
   * 03.01 General Animations
   *
   * Note: Get easeTypes at: http://james.padolsey.com/demos/jquery/easing/
   *
   *
   ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: */



  /* ------------------------------------------------------------
   * 01.01 getElementPos
   * ------------------------------------------------------------
   * DESC: returns the offset of a jquery obj
   * 
   * $elem | string | none | required | Represents a jquery selector for the postion to be returned
   * $customOffset | int | 0 | optional | Allows you to adjust the returned offset by - or + integers
   * $angle | string | top | optional | The type of offset to return
   * 
   * --------------------------------------------------------- */
   
  function getElementPos ( elem, customOffset, angle ) {

    // default args
    var customOffset = typeof customOffset !== 'undefined' ? customOffset : 0;
    var angle = typeof angle !== 'undefined' ? angle : 'top';

    // subtract a pixel to the actual position so that anchor links begin "inside" the element
    startInsideOffset = angle == 'left' || angle == 'top' ? -1 : 1;
   
    switch( angle ) { // get the position

      case 'top' : 
        var pos = $(elem).offset().top;
        break;

      case 'right' :
        var adjustRight = $(elem).width();
        var pos = $(elem).offset().left + adjustRight;
        break;

      case 'bottom' :
        var adjustBottom = $(elem).height();
        var pos = $(elem).offset().top + adjustBottom;
        break;

      case 'left' : 
        var pos = $(elem).offset().left;
        break;

      default : var pos = $(elem).offset().left;

    } 

    // adjust for Offsets
    pos = pos + customOffset + startInsideOffset;

    return pos;

  }


  /* ------------------------------------------------------------
   * 01.02 scrollToLink
   * ------------------------------------------------------------
   * DESC: adds scrolling to a hash link 
   * 
   * $link | string | none | required | Represents a jquery selector for the link
   * $speed | int | 2000 | optional | Allows you to control the scroll speed
   * $easeType | string | swing | optional | Control the easing of the animation. Anything other than 'swing' requires a plugin
   * 
   * --------------------------------------------------------- */

  function scrollToLink( link, speed, easeType ) {

  	$(link).click(function(event) {

      // default args
      var speed = typeof speed !== 'undefined' ? speed : 2000;
      var easeType = typeof easeType !== 'undefined' ? easeType : 'swing';

      // no linking
  		event.preventDefault();

      // get position
      var offset = $( $(this).attr('href') ).offset().top;

      // animate scroll
      $('html, body').animate({
        scrollTop: offset
        }, speed, easeType, function() {

          // is at new element

        });

  	});

  }


  /* ------------------------------------------------------------
   * 01.03 scrollToElem
   * ------------------------------------------------------------
   * DESC: document scrolls to the binded element
   * 
   * $elem | string | none | required | Represents a jquery selector for the scroll destination
   * $speed | int | 2000 | optional | Allows you to control the scroll speed
   * $easeType | string | swing | optional | Control the easing of the animation. Anything other than 'swing' requires a plugin
   * 
   * --------------------------------------------------------- */

  function scrollToElem( elem, speed, easeType ) {

    //  default args
    var speed = typeof speed !== 'undefined' ? speed : 2000;
    var easeType = typeof easeType !== 'undefined' ? easeType : 'swing';

    // get the postion
    var offset = $(elem).offset().top;

    // animate scroll
    $('html, body').animate({
      scrollTop: offset
      }, speed, easeType, function() {

        // is at new element

    });


  }


  /* ------------------------------------------------------------
   * 01.04 backToTop
   * ------------------------------------------------------------
   * DESC: document scrolls to the top of the page when binded 
   * element is clicked
   * 
   * $elem | string | none | required | Represents a jquery selector for the scroll destination
   * $speed | int | 2000 | optional | Allows you to control the scroll speed
   * $easeType | string | swing | optional | Control the easing of the animation. Anything other than 'swing' requires a plugin
   * 
   * --------------------------------------------------------- */

  function backToTop( topLink, scrollSpeed, easeType ) {

    var topLink = jQuery(topLink);

    var scrollSpeed = typeof scrollSpeed !== 'undefined' ? scrollSpeed : 1000;
    var easeType = typeof easeType !== 'undefined' ? easeType : 'swing';

    
    topLink.click(function() {
      
      jQuery("html, body").animate({ 
        scrollTop: 0 
      }, scrollSpeed, easeType, function() {

          // at top callback

      });
      
      return false;
      
    });  
    
  }
  


  /* ------------------------------------------------------------
   * 02.01 scrollTriggers
   * ------------------------------------------------------------
   * DESC: Manages the points at which animation triggers occur
   * --------------------------------------------------------- */


  function scrollTriggers( ) {

    $(window).scroll(function() {

      
      // A: Variables
      // ---------

      // general

      var currentPos = $(window).scrollTop();
      var mastheadOffset = 620; // this is the height of the intro images


      // slide positions: note, triggers position determine timing
      
      var slideHomeTop = getElementPos('#vob-slide-home', 0, 'top');
      var slideHomeBottom = getElementPos('#vob-slide-home', 0, 'bottom');

      var slide1Top = getElementPos('#vob-slide-1', 0, 'top'); 
      var slide1Bottom = getElementPos('#vob-slide-1', 0, 'bottom');

      var slide2Top = getElementPos('#vob-slide-2', 0, 'top'); 
      var slide2Bottom = getElementPos('#vob-slide-2', 0, 'bottom');


      var slide3Top = getElementPos('#vob-slide-3', 0, 'top'); 
      var slide3Bottom = getElementPos('#vob-slide-3', 0, 'bottom');

      var slideEndTop = getElementPos('#vob-slide-end', 0, 'top'); 
      var slideEndBottom = getElementPos('#vob-slide-end', 0, 'bottom');


      // interim positions: note, triggers position determine timing

      var carFixed = getElementPos('#vob-slide-home', -360, 'bottom');
      var carReturn = getElementPos('#vob-slide-end', -30, 'top');
      var truckStart = getElementPos('#vob-slide-end', -200, 'top');


      // B: Slide Triggers
      // -----------------

      // home 
      if ( currentPos > slideHomeTop && currentPos < slideHomeBottom ) {

        activeSlide = 'vob-slide-home';

      }
      
      // slide 1
      if ( currentPos > slide1Top && currentPos < slide1Bottom ) {

        activeSlide = 'vob-slide-1';

      }


      // slide 2
      if ( currentPos > slide2Top && currentPos < slide2Bottom ) {

        activeSlide = 'vob-slide-2';

      }


      // slide 3
      if ( currentPos > slide3Top && currentPos < slide3Bottom ) {

        activeSlide = 'vob-slide-3';

      }


      // slide end
      if ( currentPos > slideEndTop && currentPos < slideEndBottom ) {

        activeSlide = 'vob-slide-end';

      } 


      // C: Interim Triggers
      // -------------------

      // handle car: between home and slide 1
      if ( currentPos > carFixed && !$('#vegas-or-bust #truck').hasClass('intro-has-started') ) {

        // fix the car in the window
        $('#vegas-or-bust #car').addClass('fixed').removeClass('start');

      } else if ( currentPos < slide1Top )  { // only if it's above slide 1

        // have the car return to the document
        $('#vegas-or-bust #car').addClass('start').removeClass('fixed');

      }


      // handle car + cab: between end and slide 3
      if ( currentPos > carReturn ) { 

        // doc the car for the final scene
        $('#vegas-or-bust #car').addClass('end').removeClass('fixed'); 

        // bring in the truck
        // truckIntro(); 

        // bring in the cab
        cabIntro();

      } else if ( currentPos > slide2Bottom ) { // only if it's past slide 2

        // allow the car to return fixed in the window
        if ( !$('#vegas-or-bust #truck').hasClass('intro-has-started') )  $('#vegas-or-bust #car').addClass('fixed').removeClass('end');

        // show layers again
        $('section#layers').show();

        // stop the cab, clear it's queue (set stop to true) and reset cab animation chain
        $('#vegas-or-bust #cab').stop(true).removeClass('intro-has-started drive-off-has-started').css('left', '-756px');
        $('#vegas-or-bust #text1-fx').addClass('hide');
        $('#vegas-or-bust #car').removeClass('hide');

      }


    });

  }


  /* ------------------------------------------------------------
   * 02.02 regenerateMarkup
   * ------------------------------------------------------------
   * DESC: Rearranges Elments Outside the contents container
   * --------------------------------------------------------- */

   function regenerateMarkup() {
    
    // social media buttons

    var socialMediaPanel = {};

    socialMediaPanel.html = $('#social-media-btn-panel').html();
    socialMediaPanel.classes = $('#social-media-btn-panel').attr('class');
    
    $('#social-media-btn-panel').remove(); // remove old
    $('#vob-cta').append('<ul id="social-media-btn-panel" class="'+ socialMediaPanel.classes +'">' + socialMediaPanel.html + '</ul>'); // add new

   }




  /* ------------------------------------------------------------
   * 03.01 General Animations
   * --------------------------------------------------------- */

  function arrowIntro() {

    if ( !$('#vob-slide-home .nav-arrow').hasClass('has-fired') ) {

      $('#vob-slide-home .nav-arrow').delay(2000).animate({
        top: '180px',
        opacity: 1.0
      }, 1400, 'easeOutBack', function() {

         $('#vob-slide-home .nav-arrow').addClass('finished-animating');

      }).addClass('has-fired');

    }

  }


  function carIntro() {

    if ( !$('#vegas-or-bust #car').hasClass('on-stage') ) {

      $('#vegas-or-bust #car').removeClass('hide');

      // the offset of the canvas
      var canvasPos = $('#vegas-or-bust').offset().left;

      // arbitrarily adjust where it stops based on the canvas
      stopPos = canvasPos - 110;

      $('#vegas-or-bust #car').animate({ left: stopPos }, 1000, 'swing', function() {

         $('#vegas-or-bust #car').addClass('intro-finished');

      }).addClass('on-stage');

    } 

  }


  function truckIntro() {

    if ( !$('#vegas-or-bust #truck').hasClass('intro-has-started') ) {


      $('#vegas-or-bust #truck').animate({ left: '360px' }, 1000, 'swing', function() {

         // mark intro as completed
         $('#vegas-or-bust #truck').addClass('intro-has-finished');

         // force car back in doc
         $('#vegas-or-bust #car').addClass('end').removeClass('fixed');

         // reveal the final text
         $('#vegas-or-bust #text1-fx').removeClass('hide');

         vehiclesDriveOff();

      }).addClass('intro-has-started');

    }

  } 


  function cabIntro() {

    if ( !$('#vegas-or-bust #cab').hasClass('intro-has-started') ) {

      // hide car when cab is over
      $('#vegas-or-bust #cab').delay(2000).animate({ 

        left: '500px' 

      },
      {

        duration: 2000,

        easing: 'swing',

        step: function(now, fx) {

          var car = $('#vegas-or-bust #car');

          // when the left property is at around -100px, the cab is over the car. hide it at this point
          if ( now > -100 && !car.hasClass('hide') ) car.addClass('hide');

        },

        complete: function() {

         // mark intro as completed
         $('#vegas-or-bust #cab').addClass('intro-has-finished');

         // force car back in doc
         $('#vegas-or-bust #car').addClass('end').removeClass('fixed');

         // reveal the final text
         $('#vegas-or-bust #text1-fx').removeClass('hide');

         // vehiclesDriveOff();

         cabDriveOff();

        }

       }).addClass('intro-has-started');

    }

  } 


  function vehiclesDriveOff() {

    if ( !$('#vegas-or-bust #vehicals').hasClass('drive-off-has-started') ) {

      $('#vegas-or-bust #vehicals').animate({ left: '1054px' }, 2600, 'easeInExpo', function() {

         // finished

      }).addClass('drive-off-has-started');

    }

  }


  function cabDriveOff() {

    // people "get in the cab" by hiding the parallax layer
    $('section#layers').hide();


    if ( !$('#vegas-or-bust #cab').hasClass('drive-off-has-started') ) {


      $('#vegas-or-bust #cab').animate({ left: '940px' }, 2600, 'easeInExpo', function() {

         // mark exit as completed
         $('#vegas-or-bust #cab').addClass('drive-off-has-finished');

      }).addClass('drive-off-has-started');

    }


  }




  /* ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
   * 
   * -------------------------------
   * C: Execute Functions & Scripts    
   * -------------------------------
   * 
   ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: */


  // -------------
  // Functions
  // -------------

  scrollToLink('a.nav-arrow', 2000, 'easeInOutQuint' );

  scrollTriggers();

  arrowIntro();

  // regenerateMarkup();



  // -----------------
  // Scripts
  // -----------------

  // Scroll Direction
  // ----------------

  // alter the isScroll variable to determine scroll direction
  $(window).scroll(function(event) {

    var currentTop = $(this).scrollTop();

    isScrollUp = currentTop > lastScrollTop ? false : true; 
    lastScrollTop = currentTop;

  });


  // Stellar Config
  // --------------
  // reference: http://markdalgleish.com/projects/stellar.js/docs/

  $('body').stellar({

    verticalOffset: -1100, /* twice the height of the openner image since the ratio is a x2 */
    horizontalScrolling: false,
    horizontalOffset: 0 /* not sure where this comes from, but steller seems to arbitrarily set background position x on it's objects. enter that value here to negate it to 0 */

  }); 


} // desktop only	
	
}); // document read