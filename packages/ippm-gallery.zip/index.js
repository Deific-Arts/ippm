const gallery = document.querySelector('ippm-gallery');
const sizer = document.querySelector('[size="1x1"]');
const select = document.querySelector('ippm-gallery-container select');

select.addEventListener('change', (event) => {
  const group = event.target.value;

  if (group === 'all') {
    shuffleInstance.filter();
  } else {
    shuffleInstance.filter(group);
  }
});

const shuffleInstance = new Shuffle(gallery, {
  itemSelector: 'ippm-card',
  sizer: sizer,
});
