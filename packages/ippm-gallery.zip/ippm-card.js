import { html, css, LitElement } from 'lit';

class IPPMCard extends LitElement {
  static get styles() {
    return [
      css`
        * {
          box-sizing: border-box;
        }

        :host {
          --gutter: 6px;
          --spacing: calc(var(--gutter) * 2);
          --large-bottom: calc(var(--gutter) / -2);
          --large-factor: calc(var(--gutter) * 1.5);

          display: inline-block;
          position: absolute;
          top: 0;
          left: 0;
          transition: all 600ms ease;
        }

        :host([size='1x1']) {
          width: 20%;
          aspect-ratio: 16/18;
        }

        :host([size='2x1']) {
          width: 40%;
          aspect-ratio: 16/9;
        }

        :host([size='2x2']) {
          width: 40%;
          aspect-ratio: 16/18;
        }

        article {
          width: calc(100% - var(--large-factor));
          height: calc(100% - var(--spacing)); 
          margin-top: var(--spacing);
        }

        :host([size='2x2']) article {
          height: calc(100% - var(--large-factor));
          margin-bottom: var(--large-bottom); /* 4px */
        }

        @media screen and (max-width: 768px) {
          :host {
            width: 100% !important;
          }
        }


        figure {
          display: block;
          margin: 0;
          position: relative;
          height: 100%;
          overflow: hidden;
          background-size: 100% 100%;
          background-repeat: no-repeat;
        }

        div {
          color: #ffffff;
          position: absolute;
          bottom: 0;
          z-index: 1;
          width: 100%;
          margin: 0;
          opacity: 0;
          padding: 0.5rem 1rem;
          transition: opacity 400ms ease;
          background: rgba(0,0,0,0.75);
        }

        :host(:hover) div {
          opacity: 1;
        }

        h3 {
          font-stretch: condense;
          font-size: clamp(1.25rem, 2.75vw, 1.5rem);
          font-weight: 200;
          letter-spacing: 1px;
          margin: 0.5rem 0;
        }

        p {
          font-size: 0px;
          max-height: 0px;
          overflow: hidden;
          transition: all 300ms ease;
        }

        :host(:hover) p {
          font-size: 1rem;
          max-height: 100px;
        }

        @media screen and (max-width: 768px) {
          :host p {
            font-size: 1rem;
            max-height: 100px;
          }
        }

        p > span {
          overflow: hidden;
          text-overflow: ellipsis;
          -webkit-line-clamp: 2;
          display: -webkit-box;
          -webkit-box-orient: vertical;
        }

        a {
          cursor: pointer;
          color: #ffffff;
          font-weight: bold;
          display: flex;
          gap: 0.5rem;
          align-items: center;
          margin-top: 1rem;
          text-decoration: none;
        }

        a span {
          font-size: 2rem;
          position: relative;
          top: -2px;
        }
      `
    ];
  }

  static get properties() {
    return {
      image: {
        type: String
      },
      heading: {
        type: String
      }
    }
  }

  render() {
    return html`
      <article>
        <figure style="background-image:url(${this.image})">
          <div>
             <h3>${this.heading}</h3>
            <p>
              <span>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</span>
             <a href="#">Read Article <span>&rsaquo;</span></a>
            </p>
          </div>
        </figure>
      </article>
    `;
  }
}

customElements.get('ippm-card') || customElements.define('ippm-card', IPPMCard);
