  /* ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
   * 
   * ----------------------------
   * Section Contents
   * ----------------------------
   * A: Global Variables
   * B: Functions Library
   * C: Execute Functions & Scripts   
   *
   *
   ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: */


jQuery(document).ready(function($) {

  if (window.matchMedia("(min-width: 640px)").matches) {
    $('html').removeClass('theme-auset').addClass('theme-ausar');
  } else {
    $('html').removeClass('theme-ausar').addClass('theme-auset');
  }

  $(window).resize(function() {
    if (window.matchMedia("(min-width: 640px)").matches) {
      $('html').removeClass('theme-auset').addClass('theme-ausar');
    } else {
      $('html').removeClass('theme-ausar').addClass('theme-auset');
    }  
  });

  /* ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
   * 
   * ----------------------------
   * A: Global Variables
   * ----------------------------
   *
   ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: */

  var activeSlide = 'none';
  var lastScrollTop = 0;
  var isScrollUp = false;
  var mode = jQuery('html').hasClass('theme-ausar') ? 'desktop' : 'mobile';



  /* ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
   * 
   * ----------------------------
   * B: Functions Library
   * ----------------------------
   *
   * ------------------------------------------------------------
   * 
   * Table of Contents
   * -----------------
   *
   * 01.00 Reusable Functions
   * ------------------------
   * 01.01 getElementPos
   * 01.02 scrollToLink
   * 01.03 scrollToElem
   * 01.04 backToTop
   *
   * 02.00 General Functions
   * ----------------------- 
   * 02.01 scrollTriggers
   * 02.02 nextBtnSlide
   *
   * 03.00 Animations
   * ----------------
   * 03.01 General Animations
   * 03.02 Count Down Time
   *
   * Note: Get easeTypes at: http://james.padolsey.com/demos/jquery/easing/
   *
   *
   ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: */



  /* ------------------------------------------------------------
   * 01.01 getElementPos
   * ------------------------------------------------------------
   * DESC: returns the offset of a jquery obj
   * 
   * $elem | string | none | required | Represents a jquery selector for the postion to be returned
   * $customOffset | int | 0 | optional | Allows you to adjust the returned offset by - or + integers
   * $angle | string | top | optional | The type of offset to return
   * 
   * --------------------------------------------------------- */
   
  function getElementPos ( elem, customOffset, angle ) {

    // default args
    var customOffset = typeof customOffset !== 'undefined' ? customOffset : 0;
    var angle = typeof angle !== 'undefined' ? angle : 'top';

    // subtract a pixel to the actual position so that anchor links begin "inside" the element
    startInsideOffset = angle == 'left' || angle == 'top' ? -1 : 1;
   
    switch( angle ) { // get the position

      case 'top' : 
        var pos = $(elem).offset().top;
        break;

      case 'right' :
        var adjustRight = $(elem).width();
        var pos = $(elem).offset().left + adjustRight;
        break;

      case 'bottom' :
        var adjustBottom = $(elem).height();
        var pos = $(elem).offset().top + adjustBottom;
        break;

      case 'left' : 
        var pos = $(elem).offset().left;
        break;

      default : var pos = $(elem).offset().left;

    } 

    // adjust for Offsets
    pos = pos + customOffset + startInsideOffset;

    return pos;

  }


  /* ------------------------------------------------------------
   * 01.02 scrollToLink
   * ------------------------------------------------------------
   * DESC: adds scrolling to a hash link 
   * 
   * $link | string | none | required | Represents a jquery selector for the link
   * $speed | int | 2000 | optional | Allows you to control the scroll speed
   * $easeType | string | swing | optional | Control the easing of the animation. Anything other than 'swing' requires a plugin
   * 
   * --------------------------------------------------------- */

  function scrollToLink( link, speed, easeType ) {

  	$(link).click(function(event) {

      // default args
      var speed = typeof speed !== 'undefined' ? speed : 2000;
      var easeType = typeof easeType !== 'undefined' ? easeType : 'swing';

      // no linking
  		event.preventDefault();

      // get position
      var offset = $( $(this).attr('href') ).offset().top;

      // animate scroll
      $('html, body').animate({
        scrollTop: offset
        }, speed, easeType, function() {

          // is at new element

        });

  	});

  }


  /* ------------------------------------------------------------
   * 01.03 scrollToElem
   * ------------------------------------------------------------
   * DESC: document scrolls to the binded element
   * 
   * $elem | string | none | required | Represents a jquery selector for the scroll destination
   * $speed | int | 2000 | optional | Allows you to control the scroll speed
   * $easeType | string | swing | optional | Control the easing of the animation. Anything other than 'swing' requires a plugin
   * 
   * --------------------------------------------------------- */

  function scrollToElem( elem, speed, easeType ) {

    //  default args
    var speed = typeof speed !== 'undefined' ? speed : 2000;
    var easeType = typeof easeType !== 'undefined' ? easeType : 'swing';

    // get the postion
    var offset = $(elem).offset().top;

    // animate scroll
    $('html, body').animate({
      scrollTop: offset
      }, speed, easeType, function() {

        // is at new element

    });


  }


  /* ------------------------------------------------------------
   * 01.04 backToTop
   * ------------------------------------------------------------
   * DESC: document scrolls to the top of the page when binded 
   * element is clicked
   * 
   * $elem | string | none | required | Represents a jquery selector for the scroll destination
   * $speed | int | 2000 | optional | Allows you to control the scroll speed
   * $easeType | string | swing | optional | Control the easing of the animation. Anything other than 'swing' requires a plugin
   * 
   * --------------------------------------------------------- */

  function backToTop( topLink, scrollSpeed, easeType ) {

    var topLink = jQuery(topLink);

    var scrollSpeed = typeof scrollSpeed !== 'undefined' ? scrollSpeed : 1000;
    var easeType = typeof easeType !== 'undefined' ? easeType : 'swing';

    
    topLink.click(function() {
      
      jQuery("html, body").animate({ 
        scrollTop: 0 
      }, scrollSpeed, easeType, function() {

          // at top callback

      });
      
      return false;
      
    });  
    
  }
  


  /* ------------------------------------------------------------
   * 02.01 scrollTriggers
   * ------------------------------------------------------------
   * DESC: Manages the points at which animation triggers occur
   * --------------------------------------------------------- */

  function scrollTriggers( ) { 


    $(window).scroll(function() {

      var currentPos = $(window).scrollTop();
      var mastheadOffset = 620; // this is the height of the intro images

      // Active Slides
      // -------------

      // note: all triggers use -100 to start 100 pixels before their actual location

      // home
      var tHomeTop = getElementPos('#otc-time-home', -100, 'top');
      var tHomeBottom = getElementPos('#otc-time-home', 0, 'bottom');


      if ( currentPos > tHomeTop )  { 

        if ( currentPos < tHomeBottom ) 

          activeSlide = currentPos < tHomeTop + mastheadOffset ?  'otc-time-home' : 'otc-text-home';  
          // arrowIntro();

      }


      // time 43
      var t43Top = getElementPos('#otc-time-43', -100, 'top'); 
      var t43Bottom = getElementPos('#otc-time-43', 0, 'bottom');

      if ( currentPos > t43Top ) { 

        if ( currentPos < t43Bottom ) 

          activeSlide = currentPos < t43Top + mastheadOffset ? 'otc-time-43' : 'otc-text-43';
          animateFlag( 'otc-time-43' ); 

      }


      // time 25
      var t25Top = getElementPos('#otc-time-25', -100, 'top'); 
      var t25Bottom = getElementPos('#otc-time-25', 0, 'bottom');

      if ( currentPos > t25Top ) { 

        if ( currentPos < t25Bottom )  
          
          activeSlide = currentPos < t25Top + mastheadOffset ? 'otc-time-25' : 'otc-text-25';
          animateFlag( 'otc-time-25' ); 

      }


      // time 05
      var t05Top = getElementPos('#otc-time-05', -100, 'top'); 
      var t05Bottom = getElementPos('#otc-time-05', 0, 'bottom');

      if ( currentPos > t05Top ) { 

        if ( currentPos < t05Bottom ) 

        activeSlide = currentPos < t05Top + mastheadOffset ? 'otc-time-05' : 'otc-text-05'; 
        animateFlag( 'otc-time-05' );

      }

      // time end
      var tEndTop = getElementPos('#otc-time-end', -100, 'top'); 
      var tEndBottom = getElementPos('#otc-time-end', 0, 'bottom');

      if ( currentPos > tEndTop ) { 

        if ( currentPos < tEndBottom ) 

          // drama's over, remove the arrow
          $('#on-the-clock .down').fadeOut(1000);

      }

    });

  }





  /* ------------------------------------------------------------
   * 02.02 nextSlideBtn
   * ------------------------------------------------------------
   * DESC: Determines the next by reading the active slide
   * --------------------------------------------------------- */

  function nextSlideBtn( event ) { 

    switch ( activeSlide ) {

      // home slide
      case 'none'          : scrollToElem('#otc-time-home'); break;
      case 'otc-time-home' : scrollToElem('#otc-text-home');  break;

      // first slide
      case 'otc-text-home'  : scrollToElem('#otc-time-43'); break;
      case 'otc-time-43'    : scrollToElem('#otc-text-43'); break;

      // second slide
      case 'otc-text-43'    : scrollToElem('#otc-time-25'); break;
      case 'otc-time-25'    : scrollToElem('#otc-text-25'); break;

      // third slide
      case 'otc-text-25'    : scrollToElem('#otc-time-05'); break;
      case 'otc-time-05'    : scrollToElem('#otc-text-05'); break;

      // end slide
      case 'otc-text-05'    : scrollToElem('#otc-time-end'); break;
      case 'otc-time-end'   : scrollToElem('#otc-text-end'); break;

    }


  }


  /* ------------------------------------------------------------
   * 03.01 General Animations
   * --------------------------------------------------------- */

  function animateFlag( elemID ) {

    var flag =  $('#'+ elemID +' .flag');

    // do not trigger animations that has been fired
    if ( !flag.hasClass('has-fired') ) {

      switch( elemID ) {

        case 'otc-time-43' : countDownTime( 'otc-time-43', 2 ); break;
        case 'otc-time-25' : countDownTime( 'otc-time-25', 5 ); break;
        case 'otc-time-05' : countDownTime( 'otc-time-05', 5 ); break;

      }

      flag.addClass('has-fired').animate({
        right: '+=300px', /* this must equal the original right value */
        width: '203px',
        height: '171px',
      }, 1000, 'easeOutExpo', function() {

        flag.addClass('finished-animating');

        // show sidebar when the flag finishes
        // if ( elemID == 'otc-time-05' ) toggleSidebar( elemID );

      });

    }

  };


   function pulseTime( elemID, oDirection ) { 

    // default oDirection is 0.6
    var oDirection = typeof oDirection !== 'undefined' ? oDirection : 0.6;

    var countDown = $('#' + elemID + ' .flag > span');

    countDown.animate({
      opacity: oDirection
    }, 1500, 'swing', function() { 

      oDirection = oDirection == '0.6' ? 1.0 : 0.6; // if opacity was 0.6 before, make it 1.0 now

      pulseTime( elemID, oDirection ); 

    });


   }  

   function arrowIntro() {

    if ( !$('#on-the-clock .down').hasClass('has-fired') ) {

      $('#on-the-clock .down').animate({
        bottom: '+=60',
        opacity: 1.0
      }, 3000, 'easeOutElastic', function() {

         $('#on-the-clock .down').addClass('finished-animating');

      }).addClass('has-fired');

    }

   }


   function toggleSidebar( elemID ) {

    var sidebar = $('#' + elemID + ' aside');

    if ( !sidebar.hasClass('opened') ) { // if it's not opened

      sidebar.animate({
        left: '0px'
      }, 1800, 'easeOutExpo', function() {

        sidebar.removeClass('closed');
        sidebar.addClass('opened');

      });

    } else { // other wise it's closed

      sidebar.animate({
        left: '-426px' // use offset var by width - 30px for multiple
      }, 1000, 'easeInExpo', function() {

        sidebar.removeClass('opened');
        sidebar.addClass('closed');

      });


    }



   }



  /* ------------------------------------------------------------
   * 3.02 Count Down Times
   * --------------------------------------------------------- */

  function countDownTime( elemID, frames_num ) {

    var elem = $('#' + elemID + ' .flag > span' );

    if ( !$('html').hasClass('lt-ie9') ) { // don't count down for less than ie9

      elem.sprite({

        fps:             1,
        rewind:          false,
        start_at_frame:  2, 
        no_of_frames:    frames_num, // warning, this must always be at least 2 or higher. you'll create an infinite loop at the first frame if it isn't
        on_first_frame:  function ( obj ) {

          // first frame actions

        }, 
        on_last_frame:   function( obj ) { 

          // animate the time
          // pulseTime( elemID );

          // mark the finish
          obj.addClass('has-counted-down');

          // stop the animation 
          obj.spStop();

          // trigger side bars
          if ( elemID == 'otc-time-05' ) toggleSidebar( elemID );
          
          // reset the animation after each countdown
          obj.destroy();

        } 

      }).addClass('has-fired');

    } else { if ( elemID == 'otc-time-05' ) toggleSidebar( elemID ); /* still trigger the bar for lt-ie9 */ }

  } 




  /* ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
   * 
   * -------------------------------
   * C: Execute Functions & Scripts    
   * -------------------------------
   * 
   ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: */


  // -------------
  // Functions
  // -------------

  if ( mode == 'desktop' ) { // no js on mobile

    scrollTriggers();
    arrowIntro();

  }

  backToTop('.back-to-top', 6000, 'easeOutSine');


  // -----------------
  // Scripts
  // -----------------  

  $('a.down').click(nextSlideBtn);

  $('#on-the-clock > section > aside').click(function() { toggleSidebar( $(this).parent().attr('id') );  });

  // alter the isScroll variable to determine scroll direction
  $(window).scroll(function(event) {

    var currentTop = $(this).scrollTop();

    isScrollUp = currentTop > lastScrollTop ? false : true; 
    lastScrollTop = currentTop;

  });
	
	
});