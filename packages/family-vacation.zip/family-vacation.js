  /* ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
   * 
   * ----------------------------
   * Section Contents
   * ----------------------------
   * A: Global Variables
   * B: Functions Library
   * C: Execute Functions & Scripts   
   *
   *
   ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: */


jQuery(document).ready(function($) {

  if (window.matchMedia("(min-width: 640px)").matches) {
    $('html').removeClass('theme-auset').addClass('theme-ausar');
  } else {
    $('html').removeClass('theme-ausar').addClass('theme-auset');
  }

  $(window).resize(function() {
    if (window.matchMedia("(min-width: 640px)").matches) {
      $('html').removeClass('theme-auset').addClass('theme-ausar');
    } else {
      $('html').removeClass('theme-ausar').addClass('theme-auset');
    }
  });


  // -------------
  // Functions
  // -------------

  if ( $('html').hasClass('theme-ausar') ) { // desktop only

    // myGeneralFunction();

  } // desktop only


  // -----------------
  // Scripts
  // -----------------

  if ( $('html').hasClass('theme-ausar') ) { // desktop only

    // Plax Config
    // -----------
    // Documentation: https://github.com/cameronmcefee/plax

    $('[data-xrange]').plaxify();

    $.plax.enable({ "activityTarget": $('body') });

  } // desktop only


  if ( typeof trackTime == 'function' ) { // only run if s_code's trackTime exists

    setTimeout( function() { trackTime('MY SUMMER ADVENTURES | 15 Seconds') }, 15 * 1000);

    setTimeout( function() { trackTime('MY SUMMER ADVENTURES | 30 Seconds') }, 30 * 1000);

    setTimeout( function() { trackTime('MY SUMMER ADVENTURES | 60 Seconds') }, 60 * 1000);

  }
  

  
}); // document ready
